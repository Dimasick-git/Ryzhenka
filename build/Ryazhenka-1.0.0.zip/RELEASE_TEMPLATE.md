<!--
Release template. Fill in before publishing.
-->

# Release vX.Y.Z

## Highlights
- Summary of changes

## Changelog
- List of user-facing changes

## Assets
- List packaged files and checksums (SHA256)

## Notes
- Any special upgrade notes or compatibility warnings
