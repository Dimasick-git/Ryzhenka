# 🔄 Development Workflow Guide

Руководство по процессу разработки Ryazhenka с использованием автоматизации CI/CD.

---

## 📋 Структура веток

```
main (стабильный релиз)
  ↑
  └─ develop (интеграция всех изменений)
       ↓
    feature/* (новые функции)
    fix/* (исправления)
    docs/* (документация)
```

### Описание веток

| Ветка | Назначение | Правила |
|-------|-----------|--------|
| **main** | Стабильный код, готовый к релизу | Только PR из develop, теги для релизов |
| **develop** | Основная ветка разработки | Автоматическая сборка при каждом push |
| **feature/\*** | Новые функции | Одна функция = одна ветка |
| **fix/\*** | Исправления багов | Ссылка на Issue обязательна |
| **docs/\*** | Обновления документации | Может быть merged прямо в develop |

---

## 🚀 Процесс разработки

### 1️⃣ Начало работы над функцией

```bash
# Обновляем развилку
git fetch upstream
git checkout develop
git pull upstream develop

# Создаём ветку для функции
git checkout -b feature/my-amazing-feature
```

### 2️⃣ Разработка и тестирование

```bash
# Делаем изменения
# Коммитим со смыслом
git commit -m "feat: add cool feature"

# Локальная сборка
bash scripts/build.sh

# Проверяем результаты в папке build/
```

### 3️⃣ Обновление CHANGELOG

Добавьте вашу функцию в `CHANGELOG.md` в секции последней версии:

```markdown
## [5.0.0] — TBD
- Ваше изменение
- Исправление бага
```

### 4️⃣ Отправка на сервер

```bash
# Пушим в fork
git push -u origin feature/my-amazing-feature

# Создаём Pull Request на GitHub
# Описание должно содержать:
# - Что было изменено
# - Зачем это нужно
# - Как это тестировалось
# - Связанные Issues (если есть)
```

### 5️⃣ Автоматизация в GitHub Actions

После push в `develop`:

✅ **Автоматически запускается workflow `build.yml`**
- Собирает проект
- Генерирует архив
- Вычисляет контрольные суммы
- Выгружает артефакты

### 6️⃣ Деплой в main

Когда готовы выпустить релиз:

```bash
# В GitHub UI: Actions → Deploy to Main → Run workflow
# Или через GitHub CLI:
gh workflow run deploy.yml -f branch=develop -f merge_type=squash
```

**Что происходит при деплое:**
1. ✅ Код из `develop` мержится в `main`
2. ✅ Создаётся тег версии
3. ✅ Генерируется уведомление
4. ✅ CHANGELOG обновляется датой

### 7️⃣ Создание релиза

После деплоя в main:

```bash
# В GitHub UI: Actions → Auto Release & Build → Run workflow
# Укажите:
# - version: 5.0.0
# - release_type: major/minor/patch/beta

# Или через GitHub CLI:
gh workflow run release.yml -f version=5.0.0 -f release_type=minor
```

**Генерируется автоматически:**
- 📦 Архив с проектом
- 🔐 SHA256 контрольные суммы
- 📝 Полный чейнджлог с ссылками
- 🔗 Ссылки на все компоненты
- 📚 Справочная информация

---

## 🔨 Локальная сборка

### Базовая сборка

```bash
bash scripts/build.sh
```

Результаты в папке `dist/`:
- `Ryazhenka-X.Y.Z.zip` — архив проекта
- `checksums-sha256.txt` — контрольные суммы
- `checksums-md5.txt` — MD5 хеши
- `BUILD_REPORT.md` — отчёт о сборке

### Управление релизами

```bash
# Получить текущую версию
python3 scripts/release_manager.py version

# Посмотреть информацию о релизе
python3 scripts/release_manager.py info

# Обновить manifests.json
python3 scripts/release_manager.py manifests

# Показать последние изменения
python3 scripts/release_manager.py changes 10
```

---

## 📝 Соглашения

### Commit Messages

```
feat: добавляет новую функцию
fix: исправляет баг
docs: обновляет документацию
style: форматирование, без изменения логики
refactor: переструктуризация кода
perf: улучшение производительности
test: добавляет тесты
chore: изменения сборки, зависимостей
ci: изменения CI/CD конфигурации
```

**Пример:**
```bash
git commit -m "feat: add auto-update mechanism

- Implements background checking for new versions
- Notifies user when update is available
- Seamless update installation

Closes #123"
```

### PR Titles

```
[FEATURE] Brief description
[BUGFIX] Brief description
[DOCS] Brief description
[REFACTOR] Brief description
```

---

## 🔍 Проверка статуса

### GitHub Actions Dashboard

1. Перейди на [GitHub Actions](https://github.com/Dimasick-git/Ryzhenka/actions)
2. Выбери нужный workflow
3. Посмотри статус текущей сборки

### Статусы

| Статус | Описание |
|--------|----------|
| ✅ **Passed** | Сборка успешна, артефакты готовы |
| ⏳ **In Progress** | Сборка идёт, подожди |
| ❌ **Failed** | Что-то пошло не так, проверь логи |
| ⊘ **Cancelled** | Сборка отменена вручную |

---

## 📊 Metrics и Monitoring

### Доступная информация

- 📦 Размер сборки
- 📊 Кол-во файлов
- 🔐 Контрольные суммы
- 🌳 Текущий коммит
- 📅 Дата сборки

### Примечание для разработчиков

Все артефакты автоматически загружаются в:
- GitHub Releases (для пользователей)
- GitHub Actions (для истории)

---

## 🐛 Troubleshooting

### Сборка не запускается

1. Проверь, что файлы добавлены: `git add .`
2. Сделай коммит: `git commit -m "..."`
3. Пушни в develop: `git push origin develop`
4. Проверь [Actions](https://github.com/Dimasick-git/Ryzhenka/actions)

### Деплой не срабатывает

1. Убедись, что в develop есть новые изменения
2. Перепроверь версию в CHANGELOG.md
3. Проверь права доступа токена (должен быть `GITHUB_TOKEN`)

### Release не создаётся

1. Проверь, что развилка апдейтнута в main
2. Убедись, что версия правильного формата (X.Y.Z)
3. Посмотри логи workflow в Actions

---

## 🎯 Checklist перед релизом

- [ ] Все функции закончены и протестированы
- [ ] CHANGELOG обновлён
- [ ] README актуален
- [ ] Код залит в develop
- [ ] Пройдены все checks (build, tests)
- [ ] Подготовлено объявление (Telegram, YouTube)
- [ ] Версия в правильном формате (X.Y.Z)

---

## 🔗 Полезные ссылки

- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [GitHub CLI Documentation](https://cli.github.com/)
- [Conventional Commits](https://www.conventionalcommits.org/)
- [Semantic Versioning](https://semver.org/)

---

**Последнее обновление**: 2025-12-07
