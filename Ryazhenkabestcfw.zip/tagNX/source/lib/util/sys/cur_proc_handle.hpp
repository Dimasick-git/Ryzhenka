#pragma once

#include "common.hpp"

namespace exl::util::proc_handle {
    Handle Get();
}