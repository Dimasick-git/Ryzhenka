#pragma once

#include "lib.hpp"

namespace Dialog{
    void ShowDialog(const char* text);
}