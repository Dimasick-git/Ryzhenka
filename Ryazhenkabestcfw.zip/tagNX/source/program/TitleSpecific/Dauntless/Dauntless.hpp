#pragma once

#include "EOS/EOS.hpp"
#include "Common/Common.hpp"

namespace TitleSpecific::Dauntless{
    void StartupCallback();

    void InstallHooks();
}