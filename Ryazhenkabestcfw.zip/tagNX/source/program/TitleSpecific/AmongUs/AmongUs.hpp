#pragma once

#include "EOS/EOS.hpp"
#include "Common/Common.hpp"

namespace TitleSpecific::AmongUs{
    void StartupCallback();

    void InstallHooks();
}