#pragma once

#include "Common/Common.hpp"
#include "Common/Dialog.hpp"

namespace TitleSpecific::Minecraft{
    void StartupCallback();

    void InstallHooks();
}