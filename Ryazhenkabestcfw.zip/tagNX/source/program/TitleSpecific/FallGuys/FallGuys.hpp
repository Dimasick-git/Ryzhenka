#pragma once

#include "EOS/EOS.hpp"
#include "Common/Common.hpp"

namespace TitleSpecific::FallGuys{
    void StartupCallback();

    void InstallHooks();
}